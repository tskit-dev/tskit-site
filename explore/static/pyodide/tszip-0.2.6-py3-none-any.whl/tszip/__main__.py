import tszip.cli as cli


def main():
    cli.tszip_main()


if __name__ == "__main__":
    main()
